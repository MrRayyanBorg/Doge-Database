.open dbdogs

PRAGMA foreign_keys = true;
DROP TABLE if exists dogs;
DROP TABLE if exists breeds;

create table if not exists breeds (
  breedid INTEGER NOT NULL PRIMARY KEY,
  breedname TEXT NOT NULL,
  descriptionbreed TEXT
);

CREATE INDEX IF NOT EXISTS "breedname_idx" ON breeds (breedname);

create table if not exists dogs (
  dogid INTEGER NOT NULL PRIMARY KEY,
  dogname VARCHAR(100),
  created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  lastvisit INTEGER(4) DEFAULT (strftime('%s','now')),
  breedid INTEGER,
  FOREIGN KEY (breedid) REFERENCES breeds(breedid)
);

insert into breeds (breedname) values
("Labrador"),
("Poodle"),
("British Bulldog"),
("French Bulldog");

insert into dogs (dogname, breedid) values
("Pluto", 3),
("Spotty", 1),
("Fido", 2);

select dogname, breeds.breedname as breed
from dogs
INNER JOIN breeds ON breeds.breedid = dogs.dogid
